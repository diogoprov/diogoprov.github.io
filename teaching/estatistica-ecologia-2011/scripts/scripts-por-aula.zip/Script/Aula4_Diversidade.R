# �ndices de diversidade

library(vegan)# pacote com a fun��o "diversity"
mata.atlantica=read.table("mata.atlantica.txt", header=T)# ler conjunto de dados
mata.atlantica
sum(mata.atlantica[1,])# mudem o numero 1 por outra linha que queira testar
sum(mata.atlantica[2,])# mudem o numero 2 por outra linha que queira testar
# Notem que todas as comunidades possuem 100 indiv�duos
H=diversity(mata.atlantica, index="shannon")# calcula �ndice de Shannon para
# cada comunidade 
H
D=diversity(mata.atlantica, index="simpson")# calcula �ndice de S�mpson para
# cada comunidade. Este c�lcula o Simpson 1-D 
D
D.inv=diversity(mata.atlantica, index="invsimpson")# calcula �ndice de 
D.inv # S�mpson para cada comunidade. Este c�lcula o Simpson 1 / D. 
riqueza=specnumber(mata.atlantica) # riqueza de cada localidade
riqueza.freq=specnumber(mata.atlantica, M=2) # riqueza de cada localidade
riqueza.freq # este c�lculo (inserindo M=2 na f�rmula)implementa
# a frequ�ncia das esp�cies em rela��o a todas as amostras
# com um calculo simples podemos calcular a frequencia relativa que nos
# d� uma no��o de distribui��o da esp�cie nas amostras
freq.relativa=(riqueza.freq*100)/(nrow(mata.atlantica)) # o comando nrow 
# mostra o n�mero de linhas (ou seja, de amostras) da matriz. Uma esp�cie
# que ocorrer em todas as amostras ter� a freq.relativa = 100%
freq.relativa
diversidade.MA=cbind(riqueza, H, D, D.inv)# cria uma 
# matriz com os �ndices calculados e a riqueza de cada local.
diversidade.MA
# muitos autores mostram que os �ndices trazem respostas muito similares
# veja o gr�fico abaixo com a rela��o da riqueza com os �ndices e dos 
# �ndices entre si.
pairs(cbind(riqueza, H, D, D.inv), pch="+", col="black")

# �NDICES DE DIVERSIDADE BETA

library(vegan)
betadiver(help=TRUE)# lista dos �ndices de diversidade beta discutidos em
# Koleff et al. 2003, J.An.Ecol. 72: 367-382.

# �ndice cl�ssico de Whittaker (beta w)
salinidade=read.table("salinidade.txt", header=T)#importando o conjunto de dados
salinidade # gradiente de salinidade (linhas) e esp�cies nas colunas (n=50)
diversidade.beta=betadiver(salinidade, "w")
diversidade.beta # matriz triangular com os valores de diversidade beta entre 
# todos os pares poss�veis

# �ndices de Jaccard e Sorensen (bin�rios)
jaccard=betadiver(salinidade, "j")# �ndice de jaccard entre todas amostras
sorensen=betadiver(salinidade, "sor")# �ndice de sorensen entre todas amostras

# se voc� tiver interessado em um par espec�fico de amostras use "scores"
scores(jaccard)
scores(sorensen)

# como alternativa use o pacote "fossil"

library(fossil)


# notem que os valores dos �ndices por si trazem somente a informa��o de
# semelhan�a/diferen�a entre as amostras. Por�m n�o nos informa o que causa essa
# a varia��o desse valor. Veja as fun��es "betadisper", "adonis" e "mantel" para
# testar hip�teses espec�ficas sobre diversidade beta

�ndices de Bray-Curtis e Morisita-Horn (baseado na abund�ncia)
library(vegan)
data(mite)# �caros associados a 70 amostras de solo
bray=vegdist(mite, "bray")#an�lise similaridade de Bray-Curtis
bray
morisita.horn=vegdist(mite, "horn")#an�lise de similaridade de Morisita-Horn
morisita.horn

# um exemplo de extens�o das an�lises de similaridade para testar hip�teses �
# utilizar uma an�lise de mantel para correlacionar a matriz (p.ex. bray) 
# triangular de similaridade de esp�cies com uma matriz de similaridade ambiental

library(vegan)
data(varespec)# esp�cies de �rvores coletadas em 24 localidades
data(varechem)# caracter�sticas qu�micas dos solos das 24 localidades
dist.species=vegdist(varespec, "bray")# implementa a fun��o bray-curtis
dist.chemical=vegdist(scale(varechem), "euclidean")# a fun��o scale padroniza as
# vari�veis ambientais que est�o em unidade muito diferentes
associacao=mantel(dist.species, dist.chemical)
associacao
# valores significativo indicam que a composi��o de esp�cies � determinada pelas
# vari�veis ambientais (neste caso)

# �ndices Chao-Jaccard e Chao-Sorensen
library(fossil)

CSoren.dist=ecol.dist(ilhas, chao.sorenson, type="dis")
CSoren.simi=ecol.dist(ilhas, chao.sorenson, type="sim")
CJaccar.dist=ecol.dist(ilhas, chao.jaccard, type="dis")
CJaccar.simi=ecol.dist(ilhas, chao.jaccard, type="sim")

# usando o argumento type="dis" e type="sim" voc� calcula a matriz de
# dissimilaridade ("dis") e similaridade ("sim")

# se optar por calcular a similaridade entre duas localidades use a seguinte 
# fun��o:
library(fossil)

IlhaA=ilhas[,1]
IlhaB=ilhas[,2]
CSoren.A.B=chao.sorenson(IlhaA, IlhaB)
CJaccar.A.B=chao.jaccard(IlhaA, IlhaB)
CSoren.A.B
CJaccar.A.B
# outros �ndices dispon�veis no pacote "fossil"

Comunidade.A <- c(1,0,4,3,5,0,0,7)
Comunidade.B <- c(2,1,3,0,0,1,0,6)
bray.curtis(Comunidade.A, Comunidade.B)
jaccard(Comunidade.A, Comunidade.B)
simpson(Comunidade.A, Comunidade.B)
sorenson(Comunidade.A, Comunidade.B)
morisita.horn(Comunidade.A, Comunidade.B)

# Teste de homogeneidade de dispers�es multivariadas (vamos chamar de "HDM")
library(vegan)# possui as fun��es betadisper que faz a an�lise HDM e vegdist
# que calcula a dissimilaridade com seu �ndice de interesse
cafe=read.table("cafe.txt", header=T)# ler a planilha de interesse
head(cafe)#conferir parte da planilha que voc� importou no R
tipo.matriz=factor(c(rep(1,16), rep(2,8)), labels = c("com.mata","sem.mata"))
# o comando acima cria os fatores. Ou seja, os grupos que voc� quer comparar
# neste exemplo voc� que testar se a diversidade beta dos "polinizadores"
# do caf� � maior em planta��es rodeadas por mata atl�ntica ou por pasto.
tipo.matriz
dissimilaridade=vegdist(cafe, "bray")
head(dissimilaridade)
HDM=betadisper(dissimilaridade, tipo.matriz)# fun��o que faz a HDM
HDM
valor.P=permutest(HDM, pairwise = F)
valor.P
plot(HDM)