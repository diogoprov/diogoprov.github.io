##GR�FICOS##
************

xyplot(lat ~ long, data=quakes, cex=3, pch=".")
#Exibe a localiza��o dos terremotos no oceano pac��fico
tpplot= xyplot(lat ~ long, data=quakes, cex=3, pch=".")
print(tpplot)
tplot <-update(tplot, main="Earthquakes in the Pacific Ocean (since 1964)")#adiciona uma legenda no alto do  gr�fico
plot(melanoma, pch=24, xlabs="Frequ�ncia"�, ylabs="Anos", bty="L")
x=rnorm(1000, mean=0, sd=1)#cria um conjunto de dados aleatórios com distribuição normal
hist(x, xlab="Observa��es", ylab="Frequ�ncia", col="gray") #plota um histograma com as barras na cor cinza
points(mean(x), 0, pch=21, bg="red") # cria um ponto em formano de c�rculo no eixo x e y no lugar da m�dia
points(quantile(x, c(0.05, 0.95)), c(0,0), pch=24, bg="green") #cria dois pontos representando os quantis em formato de triângulos invertidos verdes
legend("topleft", c("mean", "quatiles"), pch=c(21,24)) #plota legenda no canto superior esquerdo, com os s�mbolos usados (tri�ngulo e c�rculo) e com os t�tulos (mean, quantiles) 
pt.bg=c("red", "green")) #colore os s�mbolos da legenda

#�rvores filogen�ticas
mamiferos=read.tree(text="(Bos_taurus:0.69,(Hylobates_lar:0.36,(Pongo_borneo:0.34,(Gorilla_gorilla:0.17,(Pan_paniscus:0.19,Homo_sapiens:0.12):0.08):0.06):0.15):0.55,Rattus_rattus:1.21);")
plot(mamiferos, type="cladogram")
