## ABRIR O PACOTE
####################

library (vegan)
library(BiodiversityR)

## COMANDOS RAREFA��O
########################

## rarefy(x, sample, se = FALSE, MARGIN = 1)

## X = COMUNIDADE
## sample = tamanho da sub-amostra
## se = desvio padr�o
## MARGIN = # MARGIN 1 = esp�cies na coluna
		# MARGIN 2 = esp�cies nas linhas


## ABRINDO O ARQUIVO COM O EXEMPLO
######################################

rare <- read.csv("C:/Users/Nandao/Documents/Disciplinas/Disciplina R/rarefacao.csv",
	header=T)
rare

## Soma abundancia total para cada comunidade
**********************************************

sum(rare$roedores)## Abund�ncia total
sum(rare$roedores1)## Abund�ncia total
sum(rare$roedores2)## Abund�ncia total


## Riqueza de esp�cie total para cada comunidade
**************************************************

specnumber(rare, MARGIN =  2)# n�mero de esp�cies por comunidade


## Rarefa��o para amostras de 30 individuos
**********************************************

rarefy(rare$roedores, sample = 30, MARGIN = 2)
rarefy(rare$roedores1, sample = 30, MARGIN = 2)
rarefy(rare$roedores2, sample = 30, MARGIN = 2)


## Para realizar rarefa��o para diferentes valores de sub-amostras
## eu crio um comando com diversos tamanhos de amostras

amostras1 <- c(seq(5, 40, by = 1))
amostras2 <- c(seq(5, 80, by = 1))
amostras3 <- c(seq(5, 70, by = 1))


## Rarefa��o para varias amostras 
**********************************************

roedor1 <- rarefy(rare$roedores, sample = amostras1, se = T, MARGIN = 2)
roedor2 <- rarefy(rare$roedores1, sample = amostras2, se = T, MARGIN = 2)
roedor3 <- rarefy(rare$roedores2, sample = amostras3, se = T, MARGIN = 2)


## GRAFICO
############

plot(amostras2, roedor2[1,], ylab = "Riqueza de esp�cies",
	xlab = "No. de Individuos",
	ylim = c(1, 9), xlim = c(1,
	90), type= "n")
text(30, 9, "Rarefa��o comunidade de roedores")

lines(amostras1, roedor1[1, ], type = "b", col = "red", lwd = 1.7)
lines(amostras2 + 0.2, roedor2[1, ], type = "b", col = "blue", lwd = 1.7)
lines(amostras3 + 0.4, roedor3[1, ], type = "b", col = "black", lwd = 1.7)

## Legenda
************

labs<-c("Comunidade 1","Comunidade 2", "Comunidade 3")
legend(locator(1), labs, lty = c(1,2,3), col = c("red", "blue", "black") , 
	bty = "n")

abline(h = 0, v = 40, col = "yellow")

## desvio padrao
***********************

lines(amostras1, roedor1[1, ] + roedor1[2, ], lwd = 1.7,
	lty = 1, col = "red")
lines(amostras1, roedor1[1, ] - roedor1[2, ], lwd = 1.7,
	lty = 1, col = "red")
lines(amostras2, roedor2[1, ] + roedor2[2, ], lwd = 1.7,
	lty = 2, col = "blue")
lines(amostras2, roedor2[1, ] - roedor2[2, ], lwd = 1.7,
	lty = 2, col = "blue")
lines(amostras3, roedor3[1, ] + roedor3[2, ], lwd = 1.7,
	lty = 3, col = "black")
lines(amostras3, roedor3[1, ] - roedor3[2, ], lwd = 1.7,
	lty = 3, col = "black")



## EXEMPLO DO VEGAN
####################

data(BCI) ##  CARREGA DADOS DO VEGAN - 50 PLOTS DE 1 ha e 225 especies
head (BCI) ## para facilitar a visualiza��o da planilha


## Diminuir o tamanho da planilha para facilitar
*************************************************

bci <- BCI[seq(5, 50, by = 5), ] ## SEPARA 10 PLOTS PARA FACILITAR VISUALIZAZAO
bci


## N�mero de esp�cies em cada amostra amostra
***********************************************

specnumber(bci, MARGIN =  1)


## Soma abundancia total para cada esp�cie
******************************************

(N <- colSums(bci))


## Soma total de indiv�duos
******************************

sum(N)


## Valores de sub-amostras 
*****************************

(subs3 <- c(seq(500, 4500, by = 500), sum(N)))


## Analise de rarefa��o para a comunidade
*******************************************

(rar3 <- rarefy(N, sample = subs3, se = T, MARG = 2))


## GRAFICO
############

plot(subs3, rar3[1, ], ylab = "Riqueza de esp�cies",
	axes = FALSE, xlab = "No. de Individuos",
	type = "n", ylim = c(80, 200), xlim = c(500,
	5000))
axis(1, at = 1:5 * 1000)
axis(2)
box()
text(2500, 200, "Rarefa��o (10 plots)")

lines(subs3, rar3[1, ], type = "b", col = "red")
lines(subs3, rar3[1, ] + 2 * rar3[2, ], lty = 3, col = "red")
lines(subs3, rar3[1, ] - 2 * rar3[2, ], lty = 3, col = "red")


## Curva rarefa��o
***************************

Coletor.curva <- specaccum(bci)


## Inserir a linha da cruva com rarefa��o
*******************************************

names(Coletor.curva)

plot(Coletor.curva$sites, Coletor.curva$richness,  xlab = "Amostras",
	 ylab = "Riqueza de esp�cies")

lines(Coletor.curva$sites, Coletor.curva$richness, type = "b", lwd = 1.7,
	lty = 1, col = "red")
lines(Coletor.curva$sites, Coletor.curva$richness + Coletor.curva$sd, 
	lwd = 1.7, lty = 4, col = "red")
lines(Coletor.curva$sites,  Coletor.curva$richness - Coletor.curva$sd, 
	lwd = 1.7,lty = 4, col = "red")

#########################################################################
#########################################################################

## ESTIMADORES DE RIQUEZA
############################


## Abrir a planilha
**********************

est <- read.csv("C:/Users/Nandao/Documents/Disciplinas/Disciplina R/estimadores.csv",
	header=T)
est


## Renomear linha
*******************

row.names(est)= c("A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "A10",
	"A11", "A12", "A13" , "A14")
est


## Primeiramente vamos criar uma Curva coletor
************************************************

Coletor <- specaccum(est, method = "collector")

## Gr�fico de uma curva do coletor
***********************************

names(Coletor)

plot(Coletor$sites, Coletor$richness,  xlab = "Amostras",
	 ylab = "Riqueza de esp�cies")

## Curva de acumula��o
***************************

Coletor.curva <- specaccum(est)


## Inserir a linha da cruva com rarefa��o
*******************************************

names(Coletor.curva)

plot(Coletor.curva$sites, Coletor.curva$richness,  xlab = "Amostras",
	 ylab = "Riqueza de esp�cies", ylim = c(0,14), col = "red")

lines(Coletor.curva$sites, Coletor.curva$richness, type = "b", lwd = 1.7,
	lty = 1, col = "red")
lines(Coletor.curva$sites, Coletor.curva$richness + Coletor.curva$sd, 
	lwd = 1.7, lty = 4, col = "red")
lines(Coletor.curva$sites,  Coletor.curva$richness - Coletor.curva$sd, 
	lwd = 1.7,lty = 4, col = "red")

arrows(Coletor.curva$sites, Coletor.curva$richness,
	Coletor.curva$sites, Coletor.curva$richness - Coletor.curva$sd, 
	lwd = 1.7, angle = 90, length = 0.1, lty = 1, col = "red")

arrows(Coletor.curva$sites, Coletor.curva$richness,
	Coletor.curva$sites, Coletor.curva$richness + Coletor.curva$sd, 
	lwd = 1.7, angle = 90, length = 0.1, lty = 1, col = "red")

## ESTIMADORES COM INCIDENCIA DE ESPECIES
###########################################

## Duas maneiras para ter o valor geral de cada estimador
**********************************************************

## 1 - comando specpool

(testeInc <- specpool(est))## Valor geral

## 2 - comando diversityresult

(ER.1 <- diversityresult(est, index = "chao"))
(ER.2 <- diversityresult(est, index = "jack1"))
(ER.3 <- diversityresult(est, index = "jack2"))
(ER.4 <- diversityresult(est, index = "boot"))

## Esse outro comando mostra dados mais completos, 
## com valores para cada amostra
*********************************************************

## comando poolaccum

testeInc1 <- poolaccum(est, permutations = 100, minsize = 1)
summary(testeInc1, display = "jack1")


## Gr�fico
*************

plot(seq(1, 14, by = 1), testeInc1$means[,4], ylab = "Riqueza de esp�cies",
	xlab = "No. de Individuos", type = "n",
	ylim = c(1, 20), xlim = c(1,
	15))
text(4, 20, "Estimadores de Riqueza")

lines(seq(1, 14, by = 1), testeInc1$means[,4],lty = 3, type = "b", col = "red")
lines(seq(1, 14, by = 1), testeInc1$means[,2], type = "b", col = "blue")

labs<-c("Jackknife 1", "Sobs")
legend(locator(1), labs, lty = c(3, 1),
	col = c("red", "blue") , 
	bty = "n")

## Desvio padr�o
*****************

l1 <- sd(as.vector(testeInc1$jack1[1,]))
l2 <- sd(as.vector(testeInc1$jack1[2,]))
l3 <- sd(as.vector(testeInc1$jack1[3,]))
l4 <- sd(as.vector(testeInc1$jack1[4,]))
l5 <- sd(as.vector(testeInc1$jack1[5,]))
l6 <- sd(as.vector(testeInc1$jack1[6,]))
l7 <- sd(as.vector(testeInc1$jack1[7,]))
l8 <- sd(as.vector(testeInc1$jack1[8,]))
l9 <- sd(as.vector(testeInc1$jack1[9,]))
l10 <- sd(as.vector(testeInc1$jack1[10,]))
l11 <- sd(as.vector(testeInc1$jack1[11,]))
l12 <- sd(as.vector(testeInc1$jack1[12,]))
l13 <- sd(as.vector(testeInc1$jack1[13,]))
l14 <- sd(as.vector(testeInc1$jack1[14,]))

## Loop
**********

jacksd <- c()
for (i in 1:14) {
	jacksd [i] <-  c(sd(as.vector(testeInc1$jack1[i,])))
	}

Sobs <- c()
for (i in 1:14) {
	Sobs [i] <-  c(sd(as.vector(testeInc1$S[i,])))
	}

## mais f�cil
***************

jacksd <- apply(X = testeInc1$jack1, MARGIN = 1, FUN = sd)
Sobs <- apply(X = testeInc1$S, MARGIN = 1, FUN = sd)


lines(seq(1, 14, by = 1), testeInc1$means[,4] + jacksd, 
	lty = 3, col = "red")
lines(seq(1, 14, by = 1), testeInc1$means[,4] - jacksd,
	 lty = 3, col = "red")
lines(seq(1, 14, by = 1), testeInc1$means[,2] + Sobs, 
	lty = 3, col = "blue")
lines(seq(1, 14, by = 1), testeInc1$means[,2] - Sobs,
	 lty = 3, col = "blue")



## ESTIMADORES COM A ABUNDANCIA DAS ESPECIES
#############################################

## comando estaccumR

testeAbund <- estaccumR(est, permutations = 100)
summary(testeAbund)## mostra Chao 1, ACE

## S� mostrar o estimador que voc� deseja
*******************************************

summary(testeAbund, display = "ace")


## Grafico ACE
***************

plot(seq(1, 14, by = 1), testeAbund$means[,3], ylab = "Riqueza de esp�cies",
	xlab = "No. de Individuos", type = "n",
	ylim = c(1, 20), xlim = c(1,
	15))
text(4, 20, "Estimadores de Riqueza")

lines(seq(1, 14, by = 1), testeAbund$means[,4], lty = 3, 
	type = "b", col = "red")
lines(seq(1, 14, by = 1), testeAbund$means[,2], type = "b", col = "blue")

labs<-c("ACE", "Sobs")
legend(locator(1), labs, lty = c(4, 3),
	col = c("red", "blue") , 
	bty = "n")

## Loop calcular o desvio padr�o
*********************************

ACE <- c()
for (i in 1:14) {
	ACE [i] <-  c(sd(as.vector(testeAbund$ace[i,])))
	}

Sobs1 <- c()
for (i in 1:14) {
	Sobs1 [i] <-  c(sd(as.vector(testeAbund$S[i,])))
	}


## Linha com os desvios padr�es
*********************************

lines(seq(1, 14, by = 1), testeAbund$means[,2] + Sobs, 
	lty = 3, col = "blue")
lines(seq(1, 14, by = 1), testeAbund$means[,2] - Sobs,
	 lty = 3, col = "blue")
lines(seq(1, 14, by = 1), testeAbund$means[,4] + ACE, 
	lty = 4, col = "red")
lines(seq(1, 14, by = 1), testeAbund$means[,4] - ACE,
	 lty = 4, col = "red")

## Outro comando s� que a planilha deve ser de outra maneira
*************************************************************

(est1 <- colSums(est)) ## SOMA ABUND�NCIA DE CADA LINHA

## Abundancia total por coleta
********************************

## estimateR � baseada na abund�ncia de um �nico s�tio de amostragem

(testeAbund1 <- estimateR(est1))


## ESSES  COMANDO S� CALCULAM OS VALORES FINAIS DOS ESTIMADORES OU 
## VALORES ACUMULADOS POR AMOSTRAS, CONTUDO COMO COMENTADO NA AULA
## ALGUMAS VEZES QUEREMOS ESTIMAR A RIQUEZA DE ESP�CIES PELA ABUNDANCIA


## Soma da abundancia total em cada amostra
*********************************************

(Total <- rowSums(est))

## Mudo o nome da planilha que estava usando
*********************************************

(Nest <- est) 


## Crio uma nova coluna com a abundancia total
## por amostra nessa nova planilha 

Nest$Total <- Total
Nest

## Calculando estimadores finais por abundancia
*************************************************

(Accum.1 <- accumresult(est, y = Nest , scale = "Total",
	 method = "exact", conditioned=TRUE))


accumplot(Accum.1, xlab = "Abund�ncia")

(Accum.2 <- accumresult(est, y = Nest,
	scale = "Total", method = "rarefaction")) ## USANDO METODOS DIFERENTES


accumplot(Accum.2, xlab = "Individuos")

(Accum.3 <- accumresult(est, method = "rarefaction")) ## RAREFACAO POR AMOSTRA
accumplot(Accum.3)


###########################################################################
###########################################################################
## EXERCICIOS


exer <- read.csv("C:/Users/Nandao/Documents/Disciplinas/Disciplina R/rarefacao- Exercicio.csv",
	header=T)
exer

sum(exer$Fragmento)## Abund�ncia total
sum(exer$Pasto)## Abund�ncia total
sum(exer$Borda)## Abund�ncia total
sum(exer$Cana)## Abund�ncia total

specnumber(exer, MARGIN =  2)# n�mero de esp�cies por comunidade

rarefy(exer$Fragmento, sample = 30, MARGIN = 2)
rarefy(exer$Pasto, sample = 30, MARGIN = 2)
rarefy(exer$Borda, sample = 30, MARGIN = 2)
rarefy(exer$Cana, sample = 30, MARGIN = 2)

## Cria sub-amostras para rarefa��o
*************************************

am1 <- c(seq(5, 91, by = 5))
am2 <- c(seq(5, 60, by = 5))
am3 <- c(seq(5, 106, by = 5))
am4 <- c(seq(5, 152, by = 5))

Frga <- rarefy(exer$Fragmento, sample = am1, se = T, MARGIN = 2)
Pasto <- rarefy(exer$Pasto, sample = am2, se = T, MARGIN = 2)
Borda <- rarefy(exer$Borda, sample = am3, se = T, MARGIN = 2)
Cana <- rarefy(exer$Cana, sample = am4, se = T, MARGIN = 2)


## GRAFICO
############

plot(am4, Cana[1,], ylab = "Riqueza de esp�cies",
	xlab = "No. de Individuos",
	ylim = c(1, 20), xlim = c(1,
	153), type= "n")
text(15, 19, "Rarefa��o")

lines(am1, Frga[1, ], type = "b", col = "red", lwd = 1.7)
lines(am2, Pasto[1, ], type = "b", col = "blue", lwd = 1.7)
lines(am3, Borda[1, ], type = "b", col = "black", lwd = 1.7)
lines(am4, Cana[1, ], type = "b", col = "gray", lwd = 1.7)


## Legendas
**************

labs<-c("Borda", "Fragmento","Pasto", "Cana")
legend(locator(1), labs, lty = c(3, 1,2,4),
	col = c("black", "red", "blue","gray") , 
	bty = "n")

## comparando riqueza com amostras de 60 individuos
***************************************************

abline(h = 0, v = 60)

## Linhas com desvio padr�o
******************************

lines(am1, Frga[1, ] + Frga[2, ], lwd = 1.7,
	lty = 1, col = "red")
lines(am1, Frga[1, ] - Frga[2, ], lwd = 1.7,
	lty = 1, col = "red")
lines(am2, Pasto[1, ] + Pasto[2, ], lwd = 1.7,
	lty = 2, col = "blue")
lines(am2, Pasto[1, ] - Pasto[2, ], lwd = 1.7,
	lty = 2, col = "blue")
lines(am3, Borda[1, ] + Borda[2, ], lwd = 1.7,
	lty = 3, col = "black")
lines(am3, Borda[1, ] - Borda[2, ], lwd = 1.7,
	lty = 3, col = "black")
lines(am4, Cana[1, ] + Cana[2, ], lwd = 1.7,
	lty = 4, col = "gray")
lines(am4, Cana[1, ] - Cana[2, ], lwd = 1.7,
	lty = 4, col = "gray")

abline(h = 0, v = 90, col = "yellow")


## EXERCICIO 2
##############

japi <- read.table("http://www.ecologia.ufrgs.br/~adrimelo/div/japi.txt",
	 h=T) 

## Curva coletor
***************************

japi.curva.1 <- specaccum(japi, method = "collector")

## Gr�fico de uma curva do coletor
***********************************

names(japi.curva.1)

plot(japi.curva.1$sites, japi.curva.1$richness,  xlab = "Amostras",
	 ylab = "Riqueza de esp�cies")


## Curva de acumula��o
***************************

japi.curva <- specaccum(japi)


## Inserir a linha da curva com rarefa��o
*******************************************

names(japi.curva)

lines(japi.curva$sites, japi.curva$richness, type = "b", lwd = 1.7,
	lty = 1, col = "red")

## Rarefa��o por amostra
****************************

(Accum.japi <- accumresult(japi, method = "rarefaction")) 
accumplot(Accum.japi, ci.type = "polygon", col = "gray")











