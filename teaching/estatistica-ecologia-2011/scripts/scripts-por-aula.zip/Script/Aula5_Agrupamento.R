#Introdu��o �Estat��stica Multivariada
**************************************

========================
#An�lise de Agrupamento#
========================
#Se quiserem podem inserir os exerc��cios neste espa�o




#Exemplo da an�lise com o pvclust

library(pvclust)
library(vegan)

exemplo=read.table(file.choose(), h=TRUE)	#Importem o conjunto de dados Bocaina.txt

dist <- function(x, ...){
vegdist(x, ...)
}

bocaina=t(exemplo)	#Se quisermos agrupar as esp�cies, temos de transpor a matriz
analise=pvclust(bocaina, method.hclust="average", method.dist="horn") 

plot(analise, hang=-1)
pvrect(analise)

##A fun��o cophenetic n�o roda no pvclust

#Para obter o coeficiente de correla��o cofen�tica
distBocaina=vegdist(bocaina, method="horn")	#produz uma matriz de similaridade com o coeficiente de Morisita-Horn
dendro=hclust(distBocaina, method="average")	#produz um agrupamento com a fun��o hclust e o m�todo UPGMA
cophenetic(dendro)->cofresult
cor(cofresult, distBocaina)

=============================
#IndVal - Esp�cie indicadora#
=============================

install.packages(labdsv)
library(labdsv)

fitofis=c(rep(1,4), rep(2,4), rep(3,4), rep(4,4), rep(5,4))
resultado=indval(bocaina, fitofis)
summary(resultado)#Exibe os resultados para os valores significativos

#para apresentar uma tabela dos resultados gerais
resultado$maxcls
resultado$indcls
resultado$pval
tab.resultado=cbind(resultado$maxcls,resultado$indcls,resultado$pval)
colnames(tab.resultado)<-c("maxgrp", "ind. value","P")
tab.resultado

========
#ANOSIM#
========
library(vegan)
sapos.bocaina=read.table(file.choose(), h=T)
?anosim
vec.bocaina=factor(c(rep(1, 7), rep(2,7)), labels=c("Tempor�rias", "Permanentes"))
bocaina.pad=decostand(sapos.bocaina, "pa")
ex.anosim=anosim(bocaina.pad, vec.bocaina)#Calcula o ANOSIM com dados de incid�ncia
plot(ex.anosim)