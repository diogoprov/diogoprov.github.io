#RDA parcial

library(vegan)
Y=read.table("matrizY.txt")
Y
Y.pad=log(matriz.Y+1)
Y.pad
X=read.table("matrizX.txt")
X
W=read.table("matrizW.txt")
W
rda.parcial=varpart(Y, X, W, transfo="hel")# fun��o para RDA parcial. Y - vari�vel resposta; A - vari�vel preditora (ambiental) e C - Vari�vel espacial (PCNMs).
sig.YX=rda(decostand(Y, "hell"), X, W)
sig.YW=rda(decostand(Y, "hell"), W, X)
rda.parcial
anova(sig.YX, step=10000, perm.max=1000)->a1
anova(sig.YW, step=10000, perm.max=1000)->c1
a1
c1

resu.rdaparcial1<-matrix(,4,2)
resu.rdaparcial1[1,1]<-as.matrix(rda.parcial$part$indfract$Adj.R.squared)[1,1]
resu.rdaparcial1[2,1]<-as.matrix(rda.parcial$part$indfract$Adj.R.squared)[2,1]
resu.rdaparcial1[3,1]<-as.matrix(rda.parcial$part$indfract$Adj.R.squared)[3,1]
resu.rdaparcial1[4,1]<-as.matrix(rda.parcial$part$indfract$Adj.R.squared)[4,1]
resu.rdaparcial1[1,2]<-as.matrix(a1$Pr)[1]
resu.rdaparcial1[3,2]<-as.matrix(c1$Pr)[1,1]
colnames(resu.rdaparcial1)<-c('R2', 'P')
rownames(resu.rdaparcial1)<-c('a', 'b', 'c' ,'d')
Seca_Euclid_Abund<-list(resu.rdaparcial1)
write.table(Seca_Euclid_Abund,"Seca_Euclid_Abund.txt")
Seca_Euclid_Abund

write.csv(Seca_Euclid_Abund,"TESTE.csv")


# PARTICAO
mod <- varpart(mite, ~ dtri + arfl + esfl + tiso, dens.tc + localidade,
        , data=tibouchina, data=tibouchina, transfo="hel")

mm1 <- model.matrix(~ dtri + quag + arfl + esfl, data=tibouchina)[,-1]
mm2 <- model.matrix(~ tiso + dens.tc + localidade, tibouchina)[, -1]
mite.hel <- decostand(mite, "hel")
mod <- varpart(mite.hel, mm1, mm2, mite.pcnm)


# PROCRUSTES + PROTEST

# 10 - Protest

library(vegan)# pacote com a fun��o protest e procrustes
library(labdsv) #pacote com a fun��o nmds

peixes=read.table("peixes.txt", header = TRUE)
macroinvert=read.table("macroinvertebrados.txt", header = TRUE)
peixe.dist=vegdist(peixes, "bray", binary=T)
macro.dist=vegdist(macroinvert,"bray", binary=T)
nmds.peixes=bestnmds(peixe.dist)
nmds.macroinvert=bestnmds(macro.dist)
summary(nmds.peixes)
summary(nmds.macroinvert)
scores.peixes=scores(nmds.peixes, display=c("sites"), choices =1:2)
scores.macroinvert=scores(nmds.macroinvert, display=c("sites"), choices =1:2)
procr=procrustes(nmds.peixes, nmds.macroinvert)
concordancia=protest(scores.peixes, scores.macroinvert, scores = "sites", scale=T, permutations = 9999)
summary(concordancia)
plot(concordancia)


# 10 - Protest "Extendido"
#Com a an�lise anterior pode saber se peixes e macroinvetebrados tem a mesma
#resposta aos lagos, ou seja, se possuem a mesma estrutura��o espacial.
#Como alternativa, podemos testar se as caracter�sticas f�sico-qu�micas do
#riacho afetam tanto peixes quanto macroinvertebrados 
#artigo: Paavola et al. 2006, Ecological Applications 16:368-379.

library(vegan)# pacote com a fun��o protest e procrustes
library(labdsv) #pacote com a fun��o nmds

peixes=read.table("peixes.txt", header = TRUE)
macroinvert=read.table("macroinvertebrados.txt", header = TRUE)
lagos=read.table("lagos.txt", header = TRUE)

# a primeira parte da an�lise � igual a anterior que compara a concord�ncia
# entre peixes e macroinvertebrados

peixes=read.table("peixes.txt", header = TRUE)
macroinvert=read.table("macroinvertebrados.txt", header = TRUE)
peixe.dist=vegdist(peixes, "bray", binary=T)
macro.dist=vegdist(macroinvert,"bray", binary=T)
nmds.peixes=bestnmds(peixe.dist)
nmds.macroinvert=bestnmds(macro.dist)
summary(nmds.peixes)
summary(nmds.macroinvert)
scores.peixes=scores(nmds.peixes, display=c("sites"), choices =1:2)
scores.macroinvert=scores(nmds.macroinvert, display=c("sites"), choices =1:2)
concordancia=protest(scores.peixes, scores.macroinvert, scores = "sites", scale=T, permutations = 9999)
summary(concordancia)
plot(concordancia)

# padronizando os dados ambientais

lagos.pad=decostand(lagos,"standardize")
pca.lagos=rda(lagos)
scores.lagos=scores(pca.lagos)
peixe.lago=protest(scores.peixes, scores.lagos, scores = "sites", scale=T, choices =1:2, permutations = 9999)
macro.lago=protest(scores.macroinvert, scores.lagos, scores = "sites", scale=T, choices =1:2, permutations = 9999)

