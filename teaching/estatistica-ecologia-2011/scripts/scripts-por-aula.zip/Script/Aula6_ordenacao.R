#<<An�lises de ordena��o irrestritas>>#
=======================================

=====
#PCA#
=====

data(iris)
?princomp
?prcomp
teste.pca=princomp(iris, cor=T)
summary(teste.pca)
eigenvals(teste.pca)#calcula os autovalores do teste
scores(teste.pca)#exibe os scores da PCA
cor(teste.pca,teste.pca$scores)#exibe os loadings da PCA
library(vegan)
?bstick
bstick(teste.pca, tot.var=5)# calcula os autovalores dos eixos preditos pelo modelo de Broken Stick para sele��o de eixos. Só devem ser utilizados os autovalores dos eixos que forem maiores do que o predito pelo Broken Stick. Substituiir o 5 pelo n�mero de vari�veis no conjunto de dados
biplot(teste.pca)
#Importem a fun��o evplot() do Livro Numerical ecology with R e retirem os autovalores do teste
#Para testar a signific�ncia dos agrupamentos numa an�lise de ordena�o � pos�vel tomar os escores e fazer um ANOSIM

======
#PCoA#
======

#Existem várias funções no R que calculam a PCoA, aqui vamos utilizar a função pco() do pacote labdsv, mas a função pcoa() do pacote ape.

library(labdsv)
library(vegan)
data(BCI)
dist.pcoa=vegdist(BCI, method="bray")
?pco
ex.pcoa=pco(dist.pcoa, k=8)#k=número de dimensões para serem retornadas, substitua pelo número de variáveis -1.
ex.pcoa$points#scores=autovetores (% de explicação contida em cada eixo)
(ex.pcoa$eig/sum(ex.pcoa$eig))*100 #porcentagem de explição de cada eixo
bstick(35,tot.var=sum(ex.pcoa$eig)) # substitua o 35 pelo número de unidades amostrais menos 1. Baseie-se neste dado para escolher o número de eixos que serão interpretador.
summary(ex.pcoa)
plot(ex.pcoa)	

======
#nMDS#
======

library(MASS)
library(vegan)
bocaina.temp=read.table (file.choose(), h=TRUE)
boc.dist=vegdist(bocaina.temp, method="binary")#Neste exemplo não transformar os dados, já que vou isar somente dados de incidência
ex.nmds=isoMDS(boc.dist, k = 2, maxit = 100)#o "k" refere-se ao número de dimensões que serão retidas. A função isoMDS permite qrealizar a análise mesmo se houverem dados faltantes. 
plot(ex.nmds$points)
plot(ex.nmds$points, type = "n")#plotar os pontos
text(ex.nmds$points, labels = as.character(1:nrow(bocaina.temp)))#colcoar nomes nos pontos

#<<Análises de ordenação restritas>>#
=======================================

======
#RDA#
======

library(vegan)
read.table("abio.txt", header = TRUE)->abio
abio
read.table("bio.txt", header = TRUE)->bio
bio
rda(bio,abio, scan = FALSE)->teste
teste
summary(teste)
plot(teste)
scores(teste, choices=c(1,2), display=c("sp","wa","lc","bp"), scaling=2)->escores

# "wa" = Scores that are derived from the scores of sp
# "lc" = Scores that are linear combinations of var
# "bp" = Biplot Scores
escores
escores$species
escores$sites
escores$constraints
escores$biplot
cor(escores$sites,escores$constraints) # These are standard correlation coefficients between sample scores for an axis derived from the species data (the WA scores) and the sample scores that are linear combinations of the environmental variables (the LC scores)

# Teste de aleatorização para os autovalores de todos os eixos canônicos
anova.cca(spe.rda, by="axis", step=1000) 

======
#CCA#
======

library(vegan)
read.table("abio.txt", header = TRUE)->abio
head(abio)
read.table("bio.txt", header = TRUE)->bio
head(bio)
cca(bio,abio, scan = FALSE)->teste.cca
teste.cca
summary(teste.cca)
plot(teste)
scores(teste.cca, choices=c(1,2), display=c("sp","wa","lc","bp"), scaling=2)->escores

# "wa" = Scores that are derived from the scores of sp
# "lc" = Scores that are linear combinations of var
# "bp" = Biplot Scores
escores$species
write.table(escores$species, "escores_espécies.xls", quote=F)
escores$sites
escores$constraints
escores$biplot
cor(escores$sites,escores$constraints) # These are standard correlation coefficients between sample scores for an axis derived from the species data (the WA scores) and the sample scores that are linear combinations of the environmental variables (the LC scores)