##Aula 1 - Introdução ao ambiente R##
*************************************

#Cria��o e manipula��o de objetos no R
*************************************
#Vetor num�rico
a<-1
c(1,2,3,4,5)->b
dados.campo=seq(1,10,2)#cria uma sequência de números de 1 até 10, de 2 em 2
x=seq(3,10) #cria uma sequência de números de 3 até 10 sample(x, 2, replace=T)
mata.1=rep(1:2, c(10,3))#repete o número 1 10 vezes e  número 2 3 vezes
exemplo=c(1:10)
length(exemplo)

#Vetor de caracteres
dados.pessoais=c(nome="seuNome",nascimento="aniversario", estadoCivil="solteiro")
dados.pessoais

#Vetor l�gico
is.factor(x)
is.matrix(xy)
a<-1
a<1
a==1
a>=1
a!=2

#Fator
dados=factor(c("baixo", "menos baixo","m�dio","alto")) #notem que utilizei um acento em m�dio, isto � poss��vel porque esta palavra aqui � tratada como um caracter (por isso as aspas) e n�o como um objeto

is.factor(dados)#testa a conversão

#Matriz
xy=matrix(1:12, nrow=3)
nownames(xy)=LETTERS[1:3]
colnames(xy)=c(mata.1, mata.2, mata.3, mata.4)
xy
t(xy)#transp�e a matriz
class(xy)
xy[,1] #para acessar a primeira coluna de uma matriz
xy[1,] #para acessar a primeira linha de uma matriz
head(xy) #para acessar as primeiras linhas de uma matriz
tail(xy) #para acessar as últimas linhas de uma matriz
fix(xy) #edita uma matriz ou data frame
str(xy)#avalia a estrutura do objeto
summary(xy)

#Data frame
comunidade<- data.frame(especies = c("D.nanus", "S.alter","I.guentheri", "A. callipygius"), habitat = factor(c("Folhiço", "Arbóreo", "Riacho", "Poça")), altura = c(1.1, 0.8, 0.9, 1), distancia = c(1, 1.7, 0.6, 0.2))
as.data.frame(xy)#converte (coerce) a matriz que criamos acima numa data frame
class(xy) #testa a convers�o
str(comunidade)
fix(comunidade) 
edit(comunidade)

#Lista
Lista.ex <- list(name="Toyoyo", wife="Rafaela", no.children=2, child.ages=c(2,6))
Lista.ex$name

#Opera��eses aritm�ticas b�sicas
#*****************************

a*2
b*3 #observe o que aconteceu? Como foi feita essa opera��o?
b[1]*3 #e agora?
b/4
2+3
3^3
log(2)#observe o que aconteceu? Este � a fun��o que calcula o logaritmo neperiano (ln).
log10(2) #compare o resultado anterior com este. S�o diferentes?
sqrt(3)
sum(a)
mean(b)
sum(b)/length(a)
pi

#Entendendo o arquivo de ajuda
#*****************************
RSiteSearch("analysis of variance")
install.packages("sos")
???"analysis of variance"
>?aov

#Instalando e carregando pacotes
#*****************************
install.packages("vegan")
library(vegan)

#Importa��o e exporta��o de dados 	
#********************************

obj=read.table(file.choose(), header=TRUE) # este comando ir� abrir uma tela para que o usu�rio navegue nas pastas e escolha o arquivo a ser aberto.
obj=read.table("clipboard", h=T)#importa objetos que estiverem na �rea de transfer�ncia
obj=read.table("nomedoarquivo.txt", h=T) #para utilizar este argumento, o arquivo a ser importado deve estar no diret�rio de trabalho
obj=read.csv(file.choose(), h=T)
write.table(nomeDoObjeto, "NomeDoObjetoParaSerGravado.extens�o", sep=" ", quote=F, dec="."�)
sink("japi-so.xls") #Exporta pra o wd o(s) objetos que forem exibidos depois com o nome que for colocado nesta linha de comando
japi.so1
sink()#Fecha o dispositivo

?tiff
?jpeg
