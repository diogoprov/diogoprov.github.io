# Species Abundance Distributions (SADs): McGill et al. 2007, Ecol Lett. 10:995

library(vegan) # pacote que possui a fun��o radfit
rios=read.table("rios.txt", h=T)#ler a planilha de interesse
rios # conferir se os dados est�o OK.
rad.rio1=radfit(rios[1,])# implementa o teste somente para o Rio 1.
rad.rio1 # conferir resultados da an�lise
# NOTA: o menor valor de AIC representa o modelo te�rico que melhor explica os
# dados reais. No exemplo rad.rio1 o menor valor de AIC (119.52) � do modelo 
# Null, que representa o modelo "Broken Stick" 
plot(rad.rio1, xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)
# faz o gr�fico com todas as curvas e os dados reais. A linha destacada 
# representa o modelo que menos desvia dos seus dados (c�rculos pretos)
# o argumento pch=19 representa os seus dados e como ser�o representados
# modifique o valor do pch e escolha o s�mbolo de sua prefer�ncia
rad.rio2=radfit(rios[2,])# implementa o teste somente para o Rio 2.
rad.rio2
plot(rad.rio2, xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)
rad.rio3=radfit(rios[3,])# implementa o teste somente para o Rio 3.
rad.rio3
plot(rad.rio3, xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)
par(mfrow=c(2, 2))# este comando permite que os gr�ficos sejam apresentados
# na mesma janela
plot(rad.rio1, main="Rio 1", xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)
plot(rad.rio2, main="Rio 2", xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)
plot(rad.rio3, main="Rio 3", xlab="Ordem das esp�cies", ylab="Abund�ncia", pch=19)

