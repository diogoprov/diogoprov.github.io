#    Mixed Effects Models and Extensions in Ecology with R (2009)
#    Zuur, Ieno, Walker, Saveliev and Smith.    Springer
#    This file was produced by Alain Zuur (highstat@highstat.com)
#    www.highstat.com


## CARREGANDO PACOTES NECESS�RIOS PARA AS AN�LISES
###################################################

library(languageR)
library(nlme)
library(glmmML)
library(lme4)
library(AICcmodavg)
library(bestglm)
library(mgcv)
library(MuMIn)
library(pscl)
library(MASS)
library(bbmle)
library(lattice)
library(AED)## Esse pacote tem que ser baixado da p�gia
		## http://www.highstat.com/book2.htm

## CARREGANDO DADOS
#####################

data(RoadKills) ## Carregando dados - Os dados consistem do n�mero de mortes
		    ## de anf�bios em uma rodovia em 52 s�tios em Portugal


RK <- RoadKills ## Renomeando para facilitar
names(RK)

## TEORIA - Ecologia de Paisagem
## VARIAVEL RESPOSTA  - N�mero de anf�bios mortos
## QUEST�O - Quais vari�veis da paisagem melhor explicam
## a mortalidade de anf�bios? 

## TRANSFOMO ALGUMAS VARI�VEIS POR CAUSA DOS ALTOS VALORES
***********************************************************

RK$SQ.POLIC <- sqrt(RK$POLIC)
RK$SQ.WATRES <- sqrt(RK$WAT.RES)
RK$SQ.URBAN <- sqrt(RK$URBAN)
RK$SQ.OLIVE <- sqrt(RK$OLIVE)
RK$SQ.LPROAD <- sqrt(RK$L.P.ROAD)
RK$SQ.SHRUB <- sqrt(RK$SHRUB)
RK$SQ.DWATCOUR <- sqrt(RK$D.WAT.COUR)


## VERIFICANDO COLINEARIDADE ENTRE AS VARI�VEIS INDEPENDENTES
###############################################################

## COLINEARIDADE � a existencia de correla��o entre as covari�veis

Z1 <-cbind(RK$OPEN.L, RK$SQ.OLIVE, RK$MONT.S,RK$MONT, RK$SQ.POLIC,
     RK$SQ.SHRUB, RK$SQ.URBAN, RK$SQ.WATRES, RK$L.WAT.C,
     RK$L.D.ROAD, RK$SQ.LPROAD,RK$D.WAT.RES, RK$SQ.DWATCOUR,
     RK$D.PARK, RK$N.PATCH, RK$P.EDGE, RK$L.SDI)
     
corvif(Z1)

## Usamos valor de VIF = 3 para encontrar um conjunto de vari�veis 
## explicativas que n�o cont�m colinearidade, foram retirados
## uma vari�vel de cada vez, recalculados os valores de VIF,
## e repetiu o processo at� todos os valores de VIF foram inferiores a 3.


Z2 <-cbind(RK$OPEN.L, RK$MONT.S, RK$SQ.POLIC, RK$SQ.SHRUB, RK$SQ.WATRES, 
	RK$L.WAT.C, RK$SQ.LPROAD, RK$SQ.DWATCOUR, RK$D.PARK)
     
corvif(Z2)

## MODELO GLOBAL
*****************

M1 <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         SQ.DWATCOUR + D.PARK, family = poisson, data=RK)

summary(M1)


## AKAIKE INFORMATION CRITERION
**************************************

step(M1)


## AKAIKE INFORMATION CRITERION
************************************

M2 <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson, data=RK)
summary(M2)

M3 <- glm(TOT.N ~ MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson, data=RK)

M4 <- glm(TOT.N ~ L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson, data=RK)

## AKAIKE INFORMATION CRITERION
********************************

AIC <- ICtab(M1, M2, M3, M4, type = c("AIC"), weights = TRUE, 
	delta = TRUE, sort = TRUE)
AIC


## WEIGHT = s�o usados para medir a for�a da evid�ncia em favor
##          de cada um dos modelos

## n/k < 40 

AICc <- ICtab(M1, M2, M3, M4, type = c("AICc"), weights = TRUE, 
	delta = TRUE, sort = TRUE, nobs = 52)
AICc


## Configura sub-modelos em uma lista
**************************************

Modelos <- list()
Modelos [[1]] <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         SQ.DWATCOUR + D.PARK, family = poisson (link = "log"), data=RK)
Modelos [[2]] <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson (link = "log"), data=RK)
Modelos [[3]] <- glm(TOT.N ~ MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson (link = "log"), data=RK)
Modelos [[4]] <- glm(TOT.N ~ L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson, data=RK)


## Cria um vetor com nomes dos modelos
***************************************

(Modnames <- paste("Mod", 1:length(Modelos), sep=""))


## Gera uma tabela com valores de AIC 
****************************************

(res.table <- aictab(cand.set = Modelos, modnames = Modnames, 
	second.ord = FALSE)) ## FALSE ele mostra AIC

(res.table <- aictab(cand.set = Modelos, modnames = Modnames, 
	second.ord = TRUE)) ## TRUE ele mostra AICc



## TESTE DE HIP�TESES - Likelihood rate test (LRT)
###################################################

## DEVIANCE = RESIDUAL DEVIANCE = � 2 x a diferen�a entre
## o log likelihood do modelo que apresenta um ajuste perfeito (modelo
## saturado) e o modelo em quest�o. Quanto melhor o residual deviance
## melhor o modelo.
 

drop1(M1,test = "Chi") ## A diferen�a entre as deviance dos modelos
			     ## apresenta uma distribui��o chi-square com
	                 ## p1 - p2 graus de liberdade

DM1 <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, family = poisson, data = RK)

drop1(M1, test = "Chi") 

anova(DM1, M1, test = "Chi") 

## Confirmando esses informa��o com o que aprendemos anteriormente
*******************************************************************

pchisq (2.269, 1, lower.tail = F)

1 - pchisq (2.269, 1)



## CONTUDO A VIDA N�O � T�O SIMPLES
#####################################

## ANTES DE ANALISAR OS RESULTADOS E REALIZAR AS AN�LISES DE SELE��O
## VOC� PRECISA CHECAR SEUS DADOS PARA OVERDISPERS�O

## OVERDISPERS�O =  significa que a vari�ncia � maior que a m�dia

## COMO SABER SE OS DADOS APRESENTAM OVERDISPERS�O

M1 <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         SQ.DWATCOUR + D.PARK, family = poisson, data=RK)

summary(M1)


## OVERDISPERISON
*********************

(Over <- 270.23/42)



## QUASI-POISSON
#################


M4<- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         SQ.DWATCOUR + D.PARK, family = quasipoisson, data = RK)

summary(M4)


## N�o escrever na sua disserta��o ou artigo que usou uma distribui��o
## Quasi-Poisson. Quasi-Poisson n�o � uma distribui��o.
## Basta dizer que voc� fez GLM com distribui��o Poisson, 
## detectou overdispers�o, e corrigiu os erros padr�es usando um modelo
## quasi-GLM, onde a vari�ncia � dada por f � �, onde � � a m�dia 
## e f o par�metro de dispers�o.

## Veja que o par�metro de dispers�o f � estimado em 5,93. 
## Isto significa que todos os erros padr�es foram multiplicados por 2,43
## (a raiz quadrada de 5,93), e como resultado, a maioria dos par�metros
## n�o s�o mais significativas.


## SELE��O MODELOS EM QUASI-POISSON
**************************************

## Sob a hip�tese nula, os par�metros de regress�o da vari�vel independente
## omitidos s�o iguais a zero, e os F-ratio segue uma distribui��o F com
## p1 - p2 e n - p1 graus de liberdade (n � o n�mero de observa��es)

drop1(M4, test = "F")


M5 <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         D.PARK, family = quasipoisson, data = RK)

drop1(M5, test = "F")


M6 <- glm(TOT.N ~ MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         D.PARK, family = quasipoisson, data = RK)

drop1(M6, test = "F")


M7 <- glm(TOT.N ~ MONT.S + SQ.POLIC+
         SQ.SHRUB + L.WAT.C + SQ.LPROAD+
         D.PARK, family = quasipoisson, data = RK)

drop1(M7, test = "F")


M8 <- glm(TOT.N ~ MONT.S + SQ.POLIC+
         SQ.SHRUB + L.WAT.C + 
         D.PARK, family = quasipoisson, data = RK)

drop1(M8, test = "F")


M9 <- glm(TOT.N ~ MONT.S + SQ.POLIC+ L.WAT.C + 
         D.PARK, family = quasipoisson, data = RK)

drop1(M9, test = "F")


M10 <- glm(TOT.N ~ MONT.S + L.WAT.C + 
         D.PARK, family = quasipoisson, data = RK)

drop1(M10, test = "F")


M11 <- glm(TOT.N ~ L.WAT.C + 
         D.PARK, family = quasipoisson, data = RK)

drop1(M11, test = "F")


M12 <- glm(TOT.N ~ D.PARK, family = quasipoisson, data = RK)

drop1(M12, test = "F")

summary(M12)



## GRAFICO COM OS DADOS AJUSTADO PARA A CURVA QUASI POISSON-GLM E 95% IC
###########################################################################

G <- predict(M12, newdata = RK, type = "link",
	se = TRUE)
F <- exp(G$fit)
FSEUP <- exp(G$fit + 1.96 * G$se.fit)
FSELOW <- exp(G$fit - 1.96 * G$se.fit)
plot(RK$D.PARK, RK$TOT.N, xlab = "Dist�ncia at� o parque",
ylab = "N�mero de anf�bios mortos")
lines(RK$D.PARK, F, lty = 1, col = "red")
lines(RK$D.PARK, FSEUP, lty = 2, col = "red")
lines(RK$D.PARK, FSELOW, lty = 2, col = "red")


## Em Quasi-Poisson - AIC n�o � calculado

## QUASI-AIC
***************

dd1 <- dredge(M4, rank = "QAICc", chat = summary(M4)$dispersion)
MQP1 <- get.models(dd1, 1:4)
model.avg(MQP1)


## Os usu�rios devem ter em mente os riscos que tal "abordagem 
## impensada" de avalia��o de todos os modelos poss�veis possue. 
## Embora este procedimento � �til em certos casos e justificado,
## ele pode resultar na escolha de um  "melhor" modelo esp�rio.

## "Deixar o computador descobrir" � uma pobre estrat�gia e geralmente reflete
## o fato de que o pesquisador n�o se preocupou em pensar claramente 
## sobre o problema de interesse  e sua configura��o cient�fica
## (Burnham e Anderson, 2002).


## Configura sub-modelos em uma lista
**************************************

MQP <- list()
MQP [[1]] <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         SQ.DWATCOUR + D.PARK, family = poisson, data = RK)
MQP [[2]] <- glm(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         D.PARK, family = poisson, data = RK)
MQP [[3]] <- glm(TOT.N ~ MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         D.PARK, family = poisson, data = RK)
MQP [[4]] <- glm(TOT.N ~ MONT.S + SQ.POLIC +
         SQ.SHRUB + L.WAT.C + SQ.LPROAD + D.PARK, family = poisson, 
	   data = RK)
MQP [[5]] <- glm(TOT.N ~ MONT.S + SQ.POLIC+
         SQ.SHRUB + L.WAT.C + D.PARK, family = poisson, data = RK)
MQP [[6]] <- glm(TOT.N ~ MONT.S + SQ.POLIC+ L.WAT.C + 
         D.PARK, family = poisson, data = RK)
MQP [[7]] <- glm(TOT.N ~ MONT.S + L.WAT.C + 
         D.PARK, family = poisson, data = RK)
MQP [[8]] <- glm(TOT.N ~ L.WAT.C + 
         D.PARK, family = poisson, data = RK)
MQP [[9]] <- glm(TOT.N ~ D.PARK, family = poisson, data = RK)


## Cria um vetor com nomes dos modelos
***************************************

(Modnames <- paste("MQP", 1:length(MQP), sep=""))

## OVERDISPERISON
******************

c_hat(MQP[[1]])
c_hat(MQP[[2]])
c_hat(MQP[[3]])
c_hat(MQP[[4]])
c_hat(MQP[[5]])
c_hat(MQP[[6]])
c_hat(MQP[[7]])
c_hat(MQP[[8]])
c_hat(MQP[[9]])


## Gera uma tabela com valores de AIC 
****************************************

(res.table <- aictab(cand.set = MQP, modnames = Modnames, 
	second.ord = TRUE, c.hat = 5.92)) ## TRUE ele mostra AICc

##############################################################################

## COMPARANDO BINOMIAL NEGATIVA COM POISSON
**********************************************

## odTest = Compara o log-likelihood do modelo de regress�o binomial negativa
## com modelo regressao Poisson
 

NB <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         SQ.DWATCOUR + D.PARK, link="log", data=RK)

odTest(NB)

## Outra maneira de comparar BINOMIAL NEGATIVA com POISSON
**********************************************************

llhNB = logLik(NB)
llhPoisson  = logLik(M1)
d <- 2 * (llhNB - llhPoisson)
pchisq(as.numeric(d), df = 1, lower.tail = FALSE)/2 ## Binomial negativa 
								    ## � melhor


## BINOMIAL NEGATIVA
############################################################################

NB1 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         SQ.DWATCOUR + D.PARK, link="log", data=RK)
NB2 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC+
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD+
         D.PARK, link = "log", data = RK)
NB3 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.SHRUB + SQ.WATRES +
         L.WAT.C + SQ.LPROAD + D.PARK, link = "log", data = RK)
NB4 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.SHRUB + L.WAT.C + 
	SQ.LPROAD + D.PARK, link = "log", data = RK)
NB5 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + L.WAT.C + SQ.LPROAD + D.PARK, 
	link = "log", data = RK)
NB6 <- glm.nb(TOT.N ~ OPEN.L + L.WAT.C + SQ.LPROAD +  D.PARK, 
	link = "log", data = RK)
NB7 <- glm.nb(TOT.N ~ OPEN.L + L.WAT.C + D.PARK, link = "log", data = RK)

NB8 <- glm.nb(TOT.N ~ OPEN.L + D.PARK, link = "log", data = RK)


## Sele��o autom�tica
************************

AIC <- stepAIC(NB1)
AIC


## SELECAO MODELO AICc
***********************

AICc <- ICtab(NB1, NB2, NB3, NB4, NB5, NB6, NB7, NB8, type = c("AICc"), 
	weights = TRUE, delta = TRUE, sort = TRUE, nobs = 52)
AICc


## TESTE DE HIP�TESE
**********************

drop1(NB1,test="Chi")

NB2 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.POLIC +
         SQ.SHRUB + SQ.WATRES + L.WAT.C + SQ.LPROAD +
         D.PARK, link="log", data=RK)

drop1(NB2,test="Chi")


NB3 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.SHRUB + SQ.WATRES + L.WAT.C + 
	SQ.LPROAD + D.PARK, link="log", data=RK)

drop1(NB3,test="Chi")


NB4 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + SQ.SHRUB + L.WAT.C + 
	SQ.LPROAD + D.PARK, link="log", data=RK)

drop1(NB4,test="Chi")


NB5 <- glm.nb(TOT.N ~ OPEN.L + MONT.S + L.WAT.C + 
	SQ.LPROAD + D.PARK, link="log", data=RK)

drop1(NB5,test="Chi")


NB6 <- glm.nb(TOT.N ~ OPEN.L + L.WAT.C + 
	SQ.LPROAD + D.PARK, link="log", data=RK)

drop1(NB6,test="Chi")


NB7 <- glm.nb(TOT.N ~ OPEN.L + L.WAT.C + 
	D.PARK, link="log", data=RK)

drop1(NB7,test="Chi")


NB8 <- glm.nb(TOT.N ~ OPEN.L + D.PARK, link="log", data = RK)

drop1(NB8,test="Chi") ## Autores argumentaram que o valor de L.WAT.C
			    ## estavam muito pr�ximos do m�gico valor de 0.05


summary(NB8)
plot(NB8)


## NEGATIVE BINOMIAL
*********************

muNB <- predict(NB8, type = "link")
ENB <- resid (NB8, type = "deviance")
plot(x = muNB, y = ENB, main = "Negative Binomial", ylab = "residuos", 
	xlab = "predito")
abline( h = 0, v = 0)


QUASI-POISSON
***************

mu <- predict(M12, type = "response")
E <- RK$TOT.N - mu
EP2 <- E / sqrt(7.630148 * mu)
plot(x = mu, y = EP2, main = "Quasi-Poisson", ylab = "residuos", 
	xlab = "predito")
abline( h = 0, v = 0)



## COMPARANDO BINOMIAL NEGATIVA COM POISSON
**********************************************

## odTest = Compara o log-likelihood do modelo de regress�o binomial negativa
## com modelo regressao Poisson
 
odTest(NB8)




############################################################################
#############################################################################

GLM BINOMIAL
**************

## Agora mostrarei um exemplo bem simples com dados de presen�a e aus�ncia.
## GLM com dados bin�rios ou propor��o s�o tamb�m chamados de 
## regress�o log�stica

## Analisar a distribui��o de tuberculose em javalis. Modelou a ocorr�ncia
## da tuberculose como uma fun��o do comprimento do javali (cabe�a-tronco).

data(Boar)
head(Boar)

B1 = glm(Tb ~ LengthCT, family = binomial, data = Boar)
summary(B1)

MyData <- data.frame(LengthCT = seq(from = 46.5, to = 165, by = 1))
Pred <- predict(B1, newdata = MyData, type = "response")
plot(x = Boar$LengthCT, y = Boar$Tb, xlab = "Comprimento", 
	ylab = "Probabilidade de tuberculose")
lines(MyData$LengthCT,Pred)

## Likelihood rate test
************************

drop1(B1, test="Chi")



###########################################################################
## Segundo exemplo
*********************

## Parasita de veados

data(Tbdeer)

## Colinearidade
*****************

Z <- cbind(Tbdeer$OpenLand,Tbdeer$ScrubLand,Tbdeer$QuercusPlants,Tbdeer$QuercusTrees,
        Tbdeer$ReedDeerIndex,Tbdeer$EstateSize,Tbdeer$Fenced)

corvif(Z)

## Transforma em vetor
***************************

Tbdeer$fFenced <- factor(Tbdeer$Fenced)

## Propor��o
*************

Tbdeer$DeerPosProp <- Tbdeer$DeerPosCervi / Tbdeer$DeerSampledCervi

## Modelo Geral
****************

Deer2 <- glm(DeerPosProp ~ OpenLand + ScrubLand + QuercusPlants +
        QuercusTrees + ReedDeerIndex + EstateSize + fFenced,
        family = binomial,weights = DeerSampledCervi,data = Tbdeer)
summary(Deer2)


########################################################################

## Quasi-Binomial
*******************

Deer2 <- glm(DeerPosProp ~ OpenLand + ScrubLand + QuercusPlants +
        QuercusTrees + ReedDeerIndex + EstateSize + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
summary(Deer2)

drop1(Deer2,test="F")


Deer3 <- glm(DeerPosProp ~ OpenLand + ScrubLand + QuercusPlants +
        ReedDeerIndex + EstateSize + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer3,test="F")


Deer4 <- glm(DeerPosProp ~ OpenLand + ScrubLand + 
        ReedDeerIndex + EstateSize + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer4,test="F")


Deer5 <- glm(DeerPosProp ~ OpenLand + ReedDeerIndex + EstateSize + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer5,test="F")


Deer6 <- glm(DeerPosProp ~ OpenLand + ReedDeerIndex + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer6,test="F")


Deer7 <- glm(DeerPosProp ~ OpenLand + fFenced,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer7,test="F")


Deer8 <- glm(DeerPosProp ~ OpenLand,
        family = quasibinomial,weights = DeerSampledCervi,data = Tbdeer)
drop1(Deer8,test="F")



## Grafico
************

MyData <- data.frame(OpenLand = seq(from = min(Tbdeer$OpenLand),
                                to = max(Tbdeer$OpenLand),by=0.01))
P1 <- predict(Deer8, newdata = MyData, type = "link", se = TRUE)
plot(MyData$OpenLand,exp(P1$fit)/(1+exp(P1$fit)),
     type="l",ylim=c(0,1),
     xlab="Porcentagem de �rea aberta",
     ylab="Probabilidade de infec��o por E. cervi")
lines(MyData$OpenLand,exp(P1$fit+1.96*P1$se.fit)/
       (1+exp(P1$fit+1.96*P1$se.fit)),lty=2)
lines(MyData$OpenLand,exp(P1$fit-1.96*P1$se.fit)/
       (1+exp(P1$fit-1.96*P1$se.fit)),lty=2)
points(Tbdeer$OpenLand,Tbdeer$DeerPosProp)


## Esse resultado sugere que quanto maior a porcentagem de �rea aberta
## menor a probabilidade de amostrar um veado com infec��o por E. cervi.


## Visualiza��o dos res�duos
******************************

EP = resid(Deer8,type = "pearson")
mu = predict(Deer8,type = "response")
E = Tbdeer$DeerPosProp - mu
plot(x = mu,y = EP, xlab = "Predito", ylab = "Residuos",
	main= "Quasi-Binomial")


plot(Deer8)


###########################################################################
###########################################################################

## Generalized Mixed Effects Models
***********************************

## S�o usados para modelos mais complexos com design em blocos e nested dados.

## Aprensenta dois efeitos
******************************

## EFEITO FIXO - depende somente da m�dia
## EFEITO ALEAT�RIO - depende somente da vari�ncia (n�o queremos 
## medir o efeito


data(RIKZ)

## Riqueza de animais marinhos bent�nicos em nove praias, 
## cada praia com cinco amostras.
## NAP = altura da esta��o de amostral em rela��o ao n�vel da mar�

## Quest�o � se existe rela��o entre a riqueza e a NAP

## Transformo praia em fator
*******************************

RIKZ$fBeach <- factor(RIKZ$Beach)

## Modelo
**************

Mlme1 <- lme(Richness ~ NAP, random = ~1 | fBeach, data=RIKZ)
summary(Mlme1)

## Grafico
*************

F0 <- fitted(Mlme1,level=0)
F1 <- fitted(Mlme1,level=1)
I <- order(RIKZ$NAP)
NAPs <- sort(RIKZ$NAP)
plot(NAPs,F0[I],lwd=4,type="l",ylim=c(0,22),
     ylab="Riqueza de esp�cies",xlab="NAP")
for (i in 1:9){
   x1<-RIKZ$NAP[RIKZ$Beach==i]
   y1<-F1[RIKZ$Beach==i]
   K<-order(x1)
   lines(sort(x1),y1[K])
}
text(RIKZ$NAP,RIKZ$Richness,RIKZ$Beach,cex=0.9)

## Se StdDev random effect fosse 0 todos os interceptos cariam
## na linha predita


## Suponha que a rela��o entre riqueza de esp�cies e NAP � diferente em
## cada praia. Isto implica que temos que incluir um intera��o entre
## NAP * Beach no modelo. Mas isso tem um custo muito alto elevando o 
## modelo para 17 par�metros. E n�o estamos interessados no efeito da praia.
## Contudo, se existe varia��o entre praias e na intera��o NAP * Praias, n�s
## n�o podemos ignorar esses termos. Se fizermos isso, a varia��o sistem�tica
## vai aparecer nos res�duos, levando a infer�ncias erradas.
## N�s podemos aplicar o Mixed Effects Model com random intercept e 
## random slope.

Mlme2 <- lme(Richness ~ NAP,
             random = ~ 1 + NAP | fBeach, data = RIKZ)
summary(Mlme2)

## 3.54 quantidade de varia��o no intercepto da popula��o
## 1.71 varia��o no slope (inclina��o) na nove praias
## Correla��o fala que praias com interceptos mais altos tamb�m tem 
## inclina��o negativa mais alta...


## Grafico
*************

F0 <- fitted(Mlme2,level=0)
F1 <- fitted(Mlme2,level=1)
I <- order(RIKZ$NAP)
NAPs <- sort(RIKZ$NAP)
plot(NAPs,F0[I],lwd=4,type="l",ylim=c(0,22),
     ylab="Riqueza de esp�cies",xlab="NAP")
for (i in 1:9){
   x1<-RIKZ$NAP[RIKZ$Beach==i]
   y1<-F1[RIKZ$Beach==i]
   K<-order(x1)
   lines(sort(x1),y1[K])
}
text(RIKZ$NAP,RIKZ$Richness,RIKZ$Beach,cex=0.9)



## Precisamos falar de Likelihood em Mixed Models

## MAXIMUM LIKELIHOOD (ML) - escolhe os par�metros tal que L � m�xima. 
## O problema � que ML ignora o fato que intercepto e slope s�o estimados 
## tamb�m...

## RESTRICTED MAXIMUM LIKELIHOOD (REML)  - corrige o grau de liberdade


RIKZ$fExp <- RIKZ$Exposure
RIKZ$fExp[RIKZ$fExp==8]<- 10
RIKZ$fExp <- factor(RIKZ$fExp,levels = c (10,11))

M0.ML <- lme(Richness ~ NAP, data = RIKZ,
              random = ~1| fBeach, method = "ML")

M0.REML <-lme(Richness ~ NAP, random = ~1|fBeach,
              method = "REML", data = RIKZ)

M1.ML <- lme(Richness ~ NAP+fExp, data = RIKZ,
              random = ~1| fBeach, method = "ML")

M1.REML <- lme(Richness ~NAP+fExp, data = RIKZ,
              random = ~1|fBeach, method = "REML")


## PROTOCOLO 
**************

## 1 - Comece com um modelo onde o componente fixo contem todas as vari�veis
## independentes e tantas intera��es poss�veis. 

## 2 -  Ache a melhor estrutura para o modelo aleat�rio. Voc� precisa 
## comporar os modelos com REML tanto para LRT como para AIC ou BIC...

## 3 - Depois de achar o modelo aleat�rio, temos que comparar os modelos
## fixos.. Para isso temos que usar ML...

## 4 - Apresente o modelo final com REML...


## PASSO 1 e 2 - Selecionando efeito aleat�rio
***********************************************

 B1 <- gls(Richness ~ 1 + NAP * fExp,
            method = "REML", data = RIKZ)

 B2 <- lme(Richness ~1 + NAP * fExp, data = RIKZ,
        random = ~1 | fBeach, method = "REML")

 B3 <- lme(Richness ~ 1 + NAP * fExp,data = RIKZ,
        random = ~1 + NAP | fBeach, method = "REML")


## sele��o 
*************

AIC(B1, B2, B3)


anova (B1, B2, B3)


## PASSO 3 - Selecionando efeito fixo
*****************************************


 B2 <- lme(Richness ~ NAP * fExp, data = RIKZ,
        random = ~1 | fBeach, method = "ML")
summary(B2)

## Real�am a interpreta��o de valores de p pr�ximo a 0.05
## Retira a intera��o

 B3 <- lme(Richness ~  NAP + fExp, data = RIKZ,
        random = ~1 | fBeach, method = "ML")


 B3a <- lme(Richness ~  NAP , data = RIKZ,
        random = ~1 | fBeach, method = "ML")

 B3b <- lme(Richness ~  fExp , data = RIKZ,
        random = ~1 | fBeach, method = "ML")


AICc <- ICtab(B2, B3, B3a, B3b, type = c("AICc"), 
	weights = TRUE, delta = TRUE, sort = TRUE, nobs = 45)
AICc


## PASSO 4 - Modelo Final
*****************************************

B4 <- lme(Richness ~ NAP + fExp, data = RIKZ,
        random = ~1 | fBeach, method = "REML")

plot (B4)

############################################################################
############################################################################

## BEES - Os dados s�o aninhados com multiplas observa��es da mesma colm�ia
## s�o 24 colm�ias com 3 medidas por colm�ia..

## Mostrar VarIdent

data(Bees)
tail(Bees)

## Como vari�vel dependente temos densidade de esporos medido em cada
## colm�ia.. A vari�vel independente infection quantifica o grau de infec��o,
## com valores 0, 1, 2 e 3. Embora mixed effects modelling podem 
## lidar com um certo grau de dados desbalanceados, neste caso, � melhor
## converter a vari�vel infection em 0 (sem infec��o) e 1 (infectado)
## porque existes poucas observa��es com valores 2 e 3.

Bees$Infection01 <- Bees$Infection
Bees$Infection01[Bees$Infection01 > 0] <- 1
Bees$fInfection01 <- factor(Bees$Infection01)

## Transformo colm�ia em fator
******************************

Bees$fHive <- factor(Bees$Hive)
Bees$LSpobee <- log10(Bees$Spobee + 1)

## Ploto os dados por colm�ia
********************************

op <- par(mfrow = c(1, 2), mar = c(3, 4, 1, 1))
dotchart(Bees$Spobee, groups = Bees$fHive, main = "Dados sem transformar")
dotchart(Bees$LSpobee, groups = Bees$fHive, main = "Dados transformado")
par(op)


## Come�ar com uma regress�o linear e plotarei os residuos por colm�ia
************************************************************************

M1 <- lm(LSpobee ~ fInfection01 * BeesN, data = Bees)
E1 <- rstandard(M1)
plot(E1 ~ Bees$fHive, ylab = "Res�duos", xlab = "Colm�ias")
abline(0, 0)

## Op��o de colocar colm�ia como random effect
************************************************

## Vantagens

## (1) requer um extra par�metro (vari�ncia do intercepto), comparado
## com liner regress�o que requer 23 par�metros extras 

## (2) N�s podemos fazer afirma��es para colm�ias em geral n�o s� para as 
## 24 colm�ias do estudo


## Selecionando random effect
*********************************

M1 <- lme(LSpobee ~ fInfection01 * BeesN,
          random = ~ 1 | fHive, method = "REML", data = Bees)
M2 <- lme(LSpobee ~ fInfection01 * BeesN,
          random = ~ 1 + BeesN | fHive, method = "REML", data = Bees)
M3 <- lme (LSpobee ~ fInfection01 * BeesN,
          random = ~ 1 + fInfection01 | fHive, method = "REML", data = Bees)

anova(M1,M2)
anova(M1,M3)

## Verificando o modelo
**************************

plot(M1, col = 1)


## plota por infec��o
************************

boxplot(LSpobee ~ fInfection01, data = Bees, varwidth = TRUE)


## Inserimos um comando para dizer que as vari�ncias para infec��o
## s�o diferentes

## varIdent = permite modelar diferentes vari�ncias para vari�veis 
## categ�ricas

M1 <- lme(LSpobee ~ fInfection01 * BeesN,
          random = ~ 1 | fHive, method = "REML", data = Bees)

M4 <- lme(LSpobee ~ fInfection01 * BeesN,
          random = ~ 1 | fHive, method = "REML", data = Bees,
	weights = varIdent(form = ~ 1 | fInfection01))

anova(M1,M4)


## Selecionando estrutura fixa
********************************

M7full<- lme (LSpobee ~ fInfection01 * BeesN,
         random = ~ 1|fHive,
         weights = varIdent(form = ~ 1 | fInfection01),
         method = "ML", data = Bees)

M7sub <- update(M7full, .~. -fInfection01 : BeesN )
anova(M7full,M7sub)


M8full<-lme(LSpobee ~ fInfection01 + BeesN,
          random = ~ 1|fHive, method = "ML", data = Bees,
          weights = varIdent(form =~ 1 | fInfection01))

M8sub1 <- update(M8full, .~. -fInfection01 )
M8sub2 <- update(M8full, .~. -BeesN )
anova(M8full,M8sub1)
anova(M8full,M8sub2)


M9full<-lme(LSpobee ~ fInfection01,
          random = ~ 1|fHive, method="ML", data = Bees,
          weights = varIdent(form =~ 1 | fInfection01))

M9sub1<-update(M9full, .~. -fInfection01 )
anova(M9full,M9sub1)


## Modelo final
******************

Mfinal<-lme(LSpobee ~ fInfection01,
          random =~ 1|fHive, data = Bees,
          weights = varIdent(form =~ 1 | fInfection01),
          method = "REML")
summary(Mfinal)

LSpobee = 1.75 + 2.9 x fInfection + a + E

onde a ~ N(0, 0.98) e E ~  N(0, 0.36)

plot(Mfinal)


###########################################################################
###########################################################################

data (ergoStool)
head(ergoStool)
str(ergoStool)

## Esfor�o requirido por 4 diferentes mand�bulas para rasgar
## 9 diferentes objetos

fm1Stool <- lme (effort ~ Type, data = ergoStool, random = ~ 1 | Subject) 

summary(fm1Stool)


## Tentar exemplicar

(mean <- tapply(ergoStool$effort, ergoStool$Type, mean))

## O primeiro par�metro (intercepto) � a m�dia da primeira categoria
## definida por ordem alfab�tica

## O segundo par�metro � a diferen�a entre o segundo par�metro e o 
## intercepto

mean[2] - mean [1]


## O terceiro par�metro � a diferen�a entre o terceiro par�metro e o 
## intercepto

mean[3] - mean [1]

mean[4] - mean [1]


contrasts(ergoStool$Type)<- cbind( c(3,-1,-1,-1),
                                    c(0,2,-1,-1),
                                    c(0,0,-1,1))

fm2Stool <- lme (effort ~ Type, data = ergoStool, random = ~ 1 | Subject) 

summary(fm2Stool)

anova(fm1Stool)
anova(fm2Stool)


#############################################################################
#############################################################################

## EXERCICIOS


## 1 - Owls
##############

data(Owls)
names(Owls)

## log Neg
***************

Owls$LogNeg<-log10(Owls$NegPerChick+1)


#Step 2 of protocol
**********************

Form <- lme(LogNeg ~ SexParent*FoodTreatment+SexParent*ArrivalTime,
	random=~1|Nest, method = "ML", data=Owls)

summary(Form)


M1.A = update(Form,.~.-SexParent:FoodTreatment)
M1.B = update(Form,.~.-SexParent:ArrivalTime)
anova(Form,M1.A)
anova(Form,M1.B)


Form3 <- formula(LogNeg ~ SexParent + FoodTreatment + ArrivalTime)
M3.Full <- lme(Form3, random= ~1| Nest, method = "ML", data = Owls)
M3.A <- update(M3.Full, .~. -FoodTreatment)
M3.B <- update(M3.Full, .~. -SexParent)
M3.C <- update(M3.Full, .~. -ArrivalTime)
anova(M3.Full,M3.A)
anova(M3.Full,M3.B)
anova(M3.Full,M3.C)


Form4 <- formula(LogNeg ~ FoodTreatment + ArrivalTime)
M4.Full <- lme(Form4, random= ~1| Nest, method = "ML", data = Owls)
M4.A <- update(M4.Full, .~. -FoodTreatment)
M4.B <- update(M4.Full, .~. -ArrivalTime)
anova(M4.Full,M4.A)
anova(M4.Full,M4.B)


M5 <- lme(LogNeg ~ FoodTreatment + ArrivalTime, random= ~1| Nest,
	 method = "REML", data = Owls)
summary(M5)


E2<-resid(M5,type="normalized")
F2<-fitted(M5)
op<-par(mfrow=c(2,2),mar=c(4,4,3,2))
MyYlab="Residuals"

plot(x=F2,y=E2,xlab="Fitted values",ylab=MyYlab)
boxplot(E2~SexParent,data=Owls,main="Sex of parent",ylab=MyYlab)
boxplot(E2~FoodTreatment,data=Owls,main="Food treatment",ylab=MyYlab)
plot(x=Owls$ArrivalTime,y=E,main="Arrival time",ylab=MyYlab,xlab="Time (hours)")
par(op)

*****************************************************************************
### 2 ##################################################################

teste1 <- read.csv(file.choose(), header=T)

head(teste1)


GLM.1 <- glm (exclusao ~ volume, family = binomial, data = teste1)
summary (GLM.1)

GLM.2 <- glm (exclusao ~ 1, family = binomial, data = teste1)


## SELECAO MODELO AICc
***********************

AICc <- ICtab(GLM.1, GLM.2, type = c("AICc"), 
	weights = TRUE, delta = TRUE, sort = TRUE, nobs = 41)
AICc


MyData <- data.frame(volume = seq(from = 0.1,
	to = 3, by = 0.1))
Pred <- predict(GLM.1, newdata = MyData, type = "response")
plot(x = teste1$volume, y = teste1$exclusao)
lines(MyData$volume, Pred)

## GRAFICO ERRO PADRAO
############################

P1 <- predict(GLM.1, newdata = MyData, type = "link",
	se = TRUE)
plot(MyData$volume, exp(P1$fit) / (1 + exp(P1$fit)),
	type = "l", ylim = c(0, 1),
	xlab = "Volume",
	ylab = "Probabilidade de exclus�o")
lines(MyData$volume, exp(P1$fit + P1$se.fit)/
	(1 + exp(P1$fit + P1$se.fit)), lty = 2)
lines(MyData$volume, exp(P1$fit - P1$se.fit)/
	(1 + exp(P1$fit - P1$se.fit)),  lty = 2)
points(teste1$volume, y = teste1$exclusao)


## GRAFICO INTERVALO DE CONFIAN�A
############################

P1 <- predict(GLM.1, newdata = MyData, type = "link",
	se = TRUE)
plot(MyData$volume, exp(P1$fit) / (1 + exp(P1$fit)),
	type = "l", ylim = c(0, 1),
	xlab = "Volume",
	ylab = "Probabilidade de exclus�o")
lines(MyData$volume, exp(P1$fit+1.96*P1$se.fit) /
	(1 + exp(P1$fit + 1.96 * P1$se.fit)), lty = 2)
lines(MyData$volume, exp(P1$fit-1.96*P1$se.fit) /
	(1 + exp(P1$fit - 1.96 * P1$se.fit)), lty = 2)
points(teste1$volume, y = teste1$exclusao)


****************************************************************************
*****************************************************************************

## 3- SOLEA SOLEA
####################

Solea <- read.csv ("C:/Users/Nandao/Documents/ArtigosPDF/Livros/R/Analyzing ecological data/RChapter21/Solea.csv",
 	header = TRUE)

head(Solea)

## Abund�ncia do peixe Solea Solea em um estu�rio em Portugal
## Identificar quais fatores ambientais influ�nciam na escolha
## do berc�rio pela esp�cie. Os dados de abun�ncia foram coletados
## em amostras mensais conduzidas em 4 �reas durante 1995 e 1996.


## Temos 11 vari�veis.. Muitas comparado com o n�mero de amostras

## Colinearidade
*****************

Z <- cbind(Solea$depth,Solea$temp,Solea$sal,Solea$transp,
        Solea$large.sand,Solea$med.fine.sand,Solea$mud)

corvif(Z)

Y <- cbind(Solea$depth,Solea$temp,Solea$sal,Solea$transp,
        Solea$large.sand,Solea$mud)

corvif(Y)


W <- cbind(Solea$depth,Solea$temp,Solea$sal,Solea$transp,
        Solea$mud)

corvif(W)


#     Figure 21.2
*********************

par(mar = c(4.5, 4.5, 0.5, 0.5), cex.lab = 1.3, cex.axis = 1.3)

plot(Solea[, 9:12], lower.panel = panel.cor, 
     upper.panel = panel.smooth2)

## Retira large.sand e med.fine.sand, mant�m somente mud entre 
## as vari�veis correlacionadas. Tenham em mente que isso � uma escolha
## ecol�gica, n�o estat�stica.
 


#     Figure 21.4
*********************

data_solea <- data.frame(Solea.solea = Solea$Solea.solea,
                         season = as.factor(Solea$season), 
                         month = as.factor(Solea$month), 
                         area = as.factor(Solea$Area))

plot.design(Solea.solea ~ season + month + area, 
            data = data_solea, axes = T, xtick = T)
 
 
## Uma vez que Season � um classifica��o dos meses e s�o colineares
## retiramos season e mantemos month por ser mais informativa.

 
## Modelo Global
**********************

solea_glm <- glm(Solea.solea ~ temp + sal + gravel + factor(month) + mud,
                data = Solea, family = binomial)

summary(solea_glm)

## Sele��o vari�veis
***********************

drop1(solea_glm, test="Chi")


solea_glm1 <- glm(Solea.solea ~ temp + sal + gravel + factor(month),
                data = Solea, family = binomial)

drop1(solea_glm1, test="Chi")



solea_glm2 <- glm(Solea.solea ~ temp + sal + factor(month),
                data = Solea, family = binomial)

drop1(solea_glm2, test="Chi")

summary(solea_glm2)


#     Figure 21.5
******************

coplot(Solea.solea ~ sal | month, data = Solea, overlap = 0, 
	 panel = panel.smooth2, number= 5)

## S. solea prefere relativamente baixa salinidade, e existe uma probabilidade
## maior de capturar S. solea nos meses 6 e 7.


############################################################################

data(Penicillin)


mmod <- lmer (diameter ~ sample-1 + (1|plate), family = poisson, Penicillin)

summary(mmod)



