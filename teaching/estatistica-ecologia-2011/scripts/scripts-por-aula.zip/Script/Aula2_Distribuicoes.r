## DISTRIBUI��O BINOMIAL
##########################

help (Binomial) ## Ajuda com as fun��es

## DEFINI��O E CONCEITOS
###########################

dbinom(x, size, prob)## Probabilidade da vari�vel X

pbinom(q, size, prob)## Probabilidade dos valores menores que X
			   ##	� a curva de probabilidade acumulada

qbinom(p, size, prob) ## Voc� d� um valor de probabilidade e ele retorna
			    ## n�mero determinado pela probabilidade acumulada 

rbinom(n, size, prob) ## gera n�meros de sucessos aleat�rios para 
			    ## a distribui��o binomial

## EXEMPLO DA AULA
###################

dbinom(5, size = 12, prob = 0.5) ## Exato valor de 5 caras

pbinom(5, size = 12, prob = 0.5) ## Valores igual ou menores que 5

pbinom(5, size = 12, prob = 0.5, lower.tail = F)## Valores igual ou maiores 
								## que 5 	

qbinom(0.38, size = 12, prob = 0.5)## Valor acumulado - Inverso do anterior

rbinom(5, size = 12, prob = 0.5) ## N�o s�o iguais sempre - aleat�rios


## VALOR ESPERADO E M�DIA
##########################
 
 ## E = n * p
 
       12 * 0.5

## VARI�NCIA
###############

  ## V = n * p *(1 - p)

     12 * 0.5 *(1 - 0.5)

## GRAFICO MOSTRANDO A DISTRIBUI��O BINOMIAL
#############################################

plot(dbinom(seq(0,12, by =1), size = 12, prob = 0.5), type ="h",
	xlab = "Sucesso", ylab = "Probabilidade",
	main = "Fun��o distribui��o de probabilidade")

plot(pbinom(seq(0,12, by =1), size = 12, prob = 0.5), type ="h",
	xlab = "Sucesso", ylab = "Probabilidade", 
	main = " Fun��o de distribui��o acumulada")


## EXEMPLO BROM�LIA
#####################

dbinom(40, size = 100, prob = 0.5)## Probabilidade de ser encontrada em 40 
					    ## cidades no total de 100 
					    ## com probabilidade de 0.5

sum(dbinom(46:54, 100, 0.5))## Pode determinar um intervalo


## GRAFICO BROMELIA
######################################
 
plot(dbinom(seq(0,100, by =1), size = 100, prob = 0.5), type ="h",
	xlab = "Presen�a", ylab = "Probabilidade",
	main = "Fun��o distribui��o de probabilidade")

plot(pbinom(seq(0,100, by =1), size = 100, prob = 0.5), type ="h",
	xlab = "Presente", ylab = "Probabilidade", 
	main = " Fun��o de distribui��o acumulada")


##############################################################################
##############################################################################

## DISTRIBUI��O POISSON
#########################

## DEFINI��O E CONCEITOS
###########################

dpois(x, lambda)     ## Probabilidade da vari�vel X

ppois(q, lambda)     ## Probabilidade dos valores menores que X
			   ##	� a curva de probabilidade acumulada

qpois(p, lambda)      ## Voc� d� um valor de probabilidade e ele retorna
			    ## n�mero determinado pela probabilidade acumulada 

rpois(n, lambda)      ## gera n�meros de sucessos aleat�rios para 
			    ## a distribui��o poisson



## GRAFICO MOSTRANDO A DISTRIBUI��O POISSON
#############################################

plot(dpois(seq(1,15, by =1), lambda = 10), type ="h",
	xlab = "N�mero de visitas", ylab = "Probabilidade",
	main = "Fun��o distribui��o de probabilidade")

plot(ppois(seq(0,10, by =1), lambda = 2), type ="h",
	xlab = "N�mero de visitas", ylab = "Probabilidade", 
	main = " Fun��o de distribui��o acumulada")


p

## EXEMPLOS
############

dpois (0, 2)
dpois (1, 2)
dpois (2, 2)
ppois (2, 2, lower.tail = F)


## EXERCICIO TIPOS SANGUINEOS
#################################

dbinom(2, size = 5, prob = 0.4) * dbinom(1, size = 5, prob = 0.45)*
	 dbinom(1, size = 5, prob = 0.1)* dbinom(1, size = 5, prob = 0.05)



###########################################################################
###########################################################################

## DISTRIBUI��O NORMAL
#########################


## EXEMPLO DA AULA
#####################

## Qual � a probabildiade que um peixe capturado aleat�riamente
## tenha 20.15 cm ou mais? M�DIA = 17.1; Desvio = 1.21


## PRIMEIRAMENTE VAMOS VER A DISTRIBUI��O DOS DADOS
#####################################################

x = seq(12,22,by=0.1)

y=dnorm(x,mean = 17.1,sd = 1.21)

plot(x, y, type = "l", lwd = 2, col = "red", xlab = "Tamanho do peixe")

## O QUE QUEREMOS ??
#######################

area = seq(20.15, 22, by = 0.1)
y1 = dnorm(area, mean = 17.1, sd = 1.21)
polygon(c(20.15,area,22),c(0,y1,0),col="gray")

pnorm(20.15, mean = 17.1, sd = 1.21, lower.tail = F)


## EXEMPLO 2
###################

x = seq(70,130,length = 200)
y = dnorm(x, mean=100, sd=10)
plot(x, y, type="l", lwd=2, col="red")
x = seq(70, 90, length=100)
y = dnorm(x, mean=100, sd=10)
polygon(c(70,x,90),c(0,y,0), col="gray")


pnorm(90, mean = 100,sd = 10)## Probabilidade de valores menores que 90


## EXEMPLO 3
##############

x = seq(70,130,length=200)
y = dnorm(x, mean = 100, sd = 10)
plot(x, y, type="l", lwd=2, col="red")
x=seq(90, 100, length = 200)
y = dnorm(x, mean = 100, sd = 10)
polygon(c(90,x,100), c(0,y,0), col = "gray")




pnorm(100, mean=100, sd=10)- pnorm(90,mean = 100,sd = 10)


## TESTAR AS PREMISSAS DA DISTRIBUI��O NORMAL
###############################################

## 1 DESVIO PADRAO
####################

x = seq(70, 130, length=200)
y = dnorm(x, mean = 100, sd=10)
plot(x, y, type="l", lwd=2, col="red")
x = seq(90, 110, length=200)
y = dnorm(x, mean = 100, sd = 10)
polygon(c(90,x,110),c(0,y,0),col="gray")


pnorm(110, mean=100, sd=10)-pnorm(90, mean=100, sd=10)


## 2 DESVIOS PADR�ES
#####################

x=seq(70, 130, length=200)
y=dnorm(x, mean=100, sd=10)
plot(x, y, type="l", lwd=2, col="red")
x=seq(80, 120, length=200)
y=dnorm(x, mean=100, sd=10)
polygon(c(80,x,120), c(0,y,0), col = "gray")



pnorm(120, mean=100, sd=10)- pnorm(80, mean=100, sd=10)



## DESCOBRIR UM VALOR DESCONHECIDO A PARTIR DA PROBABILIDADE
#############################################################

x = seq(70, 130, length=200)
y = dnorm(x, mean=100, sd=10)
plot(x, y, type="l", lwd=2, col="red")
x = seq(70, 116.44, length=200)
y = dnorm(x, mean=100, sd=10)
polygon(c(70,x,116.44), c(0,y,0), col = "gray")
text(100, 0.015, "95%", font = 2)


qnorm(0.95, mean = 100, sd = 10)



## DETALHES
###############

x = seq(70, 130, length=200)
y = dnorm(x, mean=100, sd=10)
plot(x, y, type="l", lwd=2, col="red")
x = seq(70, 91.58, length=200)
x1 = seq(91.58,130, length=200)
y = dnorm(x, mean=100, sd=10)
y1 = dnorm(x1, mean=100, sd=10)
polygon(c(70,x,91.58), c(0,y,0), col = "gray")
text(87, 0.006, "20%", font = 2)
polygon(c(91.58,x1,130), c(0,y1,0), col = "yellow")
text(103, 0.015, "80%", font = 2)


qnorm(0.2, mean = 100, sd = 10, lower.tail = T)
qnorm(0.8, mean = 100, sd = 10, lower.tail = F)


##EXEMPLO
#############

## ALTURA M�DIA DE �RVORES NO CERRADO � DE 2.8 METROS COM DESVIO PADR�O DE
## 0.5 METROS. A PARTIR DE QUAL ALTURA ESTAR�O OS 5% MAIS ALTOS?

x = seq(1, 4.6, by = 0.1)
y = dnorm(x, mean = 2.8, sd = 0.5)
plot(x, y, type="l", lwd=2, col="red", xlab = "Altura", 
	ylab = "Probabilidae")
x = seq(3.62, 4.6, by = 0.1)
y = dnorm(x, mean = 2.8, sd = 0.5)
polygon(c(3.62,x,4.6), c(0,y,0), col = "gray")
text(3.8, 0.04, "5%", font = 2, cex = 0.8)




qnorm(0.05, mean = 2.8, sd = 0.5, lower.tail = F)


## QUERO SABER OS 5% MAIS BAIXOS.. COMO FAZER ??
#################################################



qnorm(0.05, mean = 2.8, sd = 0.5, lower.tail = T)


###########################################################################
##########################################################################
## EXERCICIOS




## 1 ##  X = n�mero de presas consumidas 2
##       m�dia = 5



dpois (2, 5)


## 2 ## a) X = n�mero de ovos predados 3
##      m�dia = 6 ovos


dpois (3, 6)


## b) 3 ou menos ovos predados

ppois (3, 6)



## 3 ## a) p = 0.01
##         n = 30
##         k > 1

pbinom(1, size = 30, prob = 0.01, lower.tail = F)

## b) m�dia = n.p = 30*0.01

ppois(1, 0.3, lower.tail = F) ## Valor muito parecido com o Binomial


## 4 ##    m�dia = 10
##         x = menor que 4

ppois(4, 10)


## 5 ##    p = 0.25
##         n = 6
##         k = 3

dbinom(3, size = 6, prob = 0.25)


## 6 ##    p = 0.3
##         n = 4
##         k > 3

pbinom(3, size = 4, prob = 0.3, lower.tail = F)


## 7 ##    p = 0.85
##         n = 15
##         k = 10

dbinom(10, size = 15, prob = 0.85)
dbinom(5, size = 15, prob = 0.15)


## 8 ##    m�dia = 400
##         desvio = 50
##         390 < x < 450


x = seq(300, 500, by = 0.01)
y = dnorm(x, mean = 400, sd = 50)
plot(x, y, type="l", lwd=2, col="red", xlab = "Comprimento", 
	ylab = "Probabilidae")
x1 = seq(390, 450, by = 0.1)
y1 = dnorm(x1, mean = 400, sd = 50)
polygon(c(390, x1 ,450), c(0,y1 ,0), col = "gray")
text(410, 0.004, "Prob = ?", font = 2, cex = 0.8)



pnorm(450, mean = 400, sd = 50)- pnorm(390, mean = 400, sd = 50)


## 9 ## a) m�dia = 4
##         desvio = 0.25
##         10% mais compridos

x = seq(3.2, 4.8, by = 0.01)
y = dnorm(x, mean = 4, sd = 0.25)
plot(x, y, type="l", lwd=2, col="red", xlab = "Altura", 
	ylab = "Probabilidae")
x1 = seq(4.32, 4.8, by = 0.1)
y1 = dnorm(x1, mean = 4, sd = 0.25)
polygon(c(4.32,x1 ,4.8), c(0,y1 ,0), col = "gray")
text(4.4, 0.25, "0.1%", font = 2, cex = 0.8)


qnorm(0.1, mean = 4, sd = 0.25, lower.tail = F)


## 10 ##   m�dia = 8
##         desvio = 2

## a  - menos que 5 mintuos

pnorm(5, mean = 8, sd = 2)


## b - Mais que 9.5 minutos

pnorm(9.5, mean = 8, sd = 2, lower.tail = F)

## c entre 7 e 10 minutos

pnorm(10, mean = 8, sd = 2) - pnorm(7, mean = 8, sd = 2)


## 10 ##   m�dia = 5
##         desvio = 0.9

## a  - 15% mais leves

qnorm(0.15, mean = 5, sd = 0.9)


## b - 50% m�dios n�o considerando os 15% mais leves

qnorm(0.65, mean = 5, sd = 0.9)

## c - 20% pesados

qnorm(0.85, mean = 5, sd = 0.9)

leves = 4,1 kg
m�dios = 4.1 < X < 5.4 Kg
pesado = 4.9 < X < 5.9 Kg
Extras = > 5.9 Kg
